GNOME Screenshot
================

GNOME Screenshot is a small utility that takes a screenshot of the whole
desktop; the currently focused window; or an area of the screen.

### Dependencies

 - GLib 2.36
 - GTK+ 3.12
 - X11
